#This file contains the application the proprty which can change as per consumer requirement
SUCCESS={"Code":"200","Status":"Success"}
BADREQUEST={"Code":"400","Status":"Bad Request"}
ERROR={"Code":"500","Status":"Error"}
SYSTEMCAPTCHA=""
LIMIT={"Status":"Limit Reached"}

